const chalk = require("chalk")
const fs = require("fs")


//documents variants
global.doc1 = 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
global.doc2 = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
global.doc3 = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
global.doc4 = 'application/zip'
global.doc5 = 'application/pdf'
global.doc6 = 'application/vnd.android.package-archive'


//if api key expire, u can generate one from here: https://beta.openai.com/account/api-keys
global.keyopenai = "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"

//batas
global.APIKeys = {
    'https://api.shinoa.xyz/docs': '451C1A14'
}

//owmner v card
global.owner = ['6287850541572'] //ur owner number
global.ownernomer = "6287850541572" //ur owner number2
global.ownername = "Kyy" //ur owner name
global.namaku = "Kyy"
global.ytname = "Kyy" //ur yt chanel name
global.socialm = "jgn di spam" //ur github or insta name
global.location = "Tangerang Banten, Indonesia " //ur location

//new
global.botname = "Rellkyy Bot"
global.ownernumber = '6287850541572'
global.ownername = 'Kyy'
global.ownerNumber = ["6287850541572@s.whatsapp.net"]
global.ownerweb = "tiktok.com/@rell_myloff"
global.websitex = "https://kyuudev.my.id"
global.wagc = "https://chat.whatsapp.com/GxpCNxNd7w99fjSzHJPwGL"
global.themeemoji = '🚩'
global.wm = "Created By Kyy"
global.wmbot = "Created By Kyy"
global.botscript = 'private' //script link
global.packname = "Rellkyy - 𝐁 𝐨 𝐭"
global.author = "Kyy"
global.creator = "6287850541572@s.whatsapp.net"
global.prefa = ['','!','.','#','&']
global.hituet = 0
global.running = "Panel Pterodactyl"
//media target
global.thum = fs.readFileSync("./XeonMedia/theme/cheemspic.jpg") //ur thumb pic
global.log0 = fs.readFileSync("./XeonMedia/theme/cheemspic.jpg") //ur logo pic
global.err4r = fs.readFileSync("./XeonMedia/theme/cheemspic.jpg") //ur error pic
global.thumb = fs.readFileSync("./XeonMedia/theme/cheemspic.jpg") //ur thumb pic

//menu image maker
global.flaming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.fluming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=fluffy-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flarun = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=runner-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flasmurf = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=smurfs-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='

//messages
global.mess = {
    success: 'Done✅',
    admin: 'fitur khusus admin',
    botAdmin: 'bot harus menjadi admin terlebih dahulu',
    premime: 'fitur khusus premium',
    owner: 'fitur khusus owner',
    group: 'Features Used Only For Groups!',
    private: 'Features Used Only For Private Chat!',
    bot: 'fitur khusus bot',
    wait: 'proses kak...',
    linkm: 'masukan linknya',
    endLimit: 'limit kamu sudah habis, limit akan di reset setelah 12 jam',
    nsfw: 'tobat woi🗿',
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})